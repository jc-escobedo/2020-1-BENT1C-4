package unidad2.ejemplo7;
// Fig. 10.9: PruebaSistemaNomina.java
// Programa de prueba para la jerarqu�a de Empleado.

public class PruebaSistemaNomina {
	public static void main(String[] args) {
		// crea un arreglo Empleado de cuatro elementos
		Empleado[] empleados = new Empleado[4];

		// UPCASTING 
		// inicializa el arreglo con objetos subclases de Empleado
		empleados[0] = new EmpleadoAsalariado("John", "Smith", "111-11-1111", 800.00);
		empleados[1] = new EmpleadoPorHoras("Karen", "Price", "222-22-2222", 16.75, 40);
		empleados[2] = new EmpleadoPorComision("Sue", "Jones", "333-33-3333", 10000, .06);
		empleados[3] = new EmpleadoBaseMasComision("Bob", "Lewis", "444-44-4444",5000, 0.04, 300);

		System.out.println("Empleados procesados en forma polimorfica:\n");

		// procesa en forma gen�rica a cada elemento en el arreglo de empleados
		for (Empleado empleadoActual : empleados) {
		//  POLIMORFISMO MISMO MENSAJE MULTPLES IMPLEMENTACIONES DEL METODO
			System.out.println(empleadoActual.toString()); 
			
			// determina si el elemento es un EmpleadoBaseMasComision para poder castear
			if (empleadoActual instanceof EmpleadoBaseMasComision) {
				// DOWNCASTING
				// conversi�n descendente de la referencia de Empleado 
				// a una referencia de EmpleadoBaseMasComision
				EmpleadoBaseMasComision empleado = (EmpleadoBaseMasComision) empleadoActual;
				empleado.setSalarioBase(1.10 * empleado.getSalarioBase());
				System.out.printf("el nuevo salario base con 10%% de aumento es : $%,.2f\n",empleado.getSalarioBase());
			}
			//  POLIMORFISMO MISMO MENSAJE MULTPLES IMPLEMENTACIONES DEL METODO INGRESOS
			System.out.printf("ingresos $%,.2f\n\n", empleadoActual.ingresos());
		}
		// obtiene el nombre del tipo de cada objeto en el arreglo de empleados
		for (int j = 0; j < empleados.length; j++)
			System.out.printf("El empleado %d es un %s\n", j, empleados[j].getClass().getSimpleName());
	}
}
/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y * Pearson Education,
 * Inc. Todos los derechos reservados. * * RENUNCIA: Los autores y el editor de
 * este libro han realizado su mejor * esfuerzo para preparar este libro. Esto
 * incluye el desarrollo, la * investigaci�n y prueba de las teor�as y programas
 * para determinar su * efectividad. Los autores y el editor no hacen ninguna
 * garant�a de * ning�n tipo, expresa o impl�cita, en relaci�n con estos
 * programas o * con la documentaci�n contenida en estos libros. Los autores y
 * el * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de * estos
 * programas. *
 *************************************************************************/