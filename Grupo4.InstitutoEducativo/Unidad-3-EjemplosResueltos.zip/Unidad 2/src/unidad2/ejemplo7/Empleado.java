package unidad2.ejemplo7;
// Fig. 10.4: Empleado.java
// La superclase abstracta Empleado.

public abstract class Empleado {
   private String primerNombre;
   private String apellidoPaterno;
   private String numeroSeguroSocial;

   // constructor con tres argumentos
   public Empleado( String primerNombre, String apellidoPaterno, String numeroSeguroSocial) {
      this.primerNombre = primerNombre;
      this.apellidoPaterno = apellidoPaterno;
      this.numeroSeguroSocial = numeroSeguroSocial;
   }
   // establece el primer primerNombre
   public void setPrimerNombre( String primerNombre ) {
      this.primerNombre = primerNombre;
   }
   // devuelve el primer primerNombre
   public String getPrimerNombre() {
      return primerNombre;
   }
   // establece el apellido paterno
   public void setApellidoPaterno( String apellidoPaterno ) {
      this.apellidoPaterno = apellidoPaterno; 
   }
   // devuelve el apellido paterno
   public String getApellidoPaterno(){
      return apellidoPaterno;
   }
   // establece el n�mero de seguro social
   public void setNumeroSeguroSocial( String numeroSeguroSocial ) {
      this.numeroSeguroSocial = numeroSeguroSocial; 
   }
   // devuelve el n�mero de seguro social
   public String getNumeroSeguroSocial() {
      return numeroSeguroSocial;
   }
   // devuelve representaci�n String de un objeto Empleado
   @Override
   public String toString() {
      return String.format( "%s %s\nnumero de seguro social: %s", getPrimerNombre(), getApellidoPaterno(), getNumeroSeguroSocial() );
   }
   // m�todo abstracto sobrescrito por las subclases concretas
   public abstract double ingresos(); // aqu� no hay implementaci�n
}

/**************************************************************************
 * (C) Copyright 1992-2012 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/