package unidad2.ejemplo7;
// Fig. 10.7: EmpleadoPorComision.java
// La clase EmpleadoPorComision extiende a Empleado.

public class EmpleadoPorComision extends Empleado {
	private double ventasBrutas;   // ventas totales por semana
	private double tarifaComision; // porcentaje de comisi�n

	public EmpleadoPorComision(String nombre, String apellido, String nss, double ventas, double tarifa) {
		super(nombre, apellido, nss);
		setVentasBrutas(ventas);
		setTarifaComision(tarifa);
	}
	public void setTarifaComision(double tarifa) {
		if (tarifa > 0.0 && tarifa < 1.0)
			tarifaComision = tarifa;
		else
			System.out.println("La tarifa de comision debe ser > 0.0 y < 1.0");
	}
	public double getTarifaComision() {
		return tarifaComision;
	}
	public void setVentasBrutas(double ventas) {
		if (ventas >= 0.0)
			ventasBrutas = ventas;
		else
			System.out.println("Las ventas brutas deben ser >= 0.0");
	}
	public double getVentasBrutas() {
		return ventasBrutas;
	}
	// calcula los ingresos; sobrescribe el m�todo abstracto ingresos en Empleado
	@Override
	public double ingresos() {
		return getTarifaComision() * getVentasBrutas();
	}
	@Override
	public String toString() {
		return String.format("%s: %s\n%s: $%,.2f; %s: %.2f", "empleado por comision", super.toString(), "ventas brutas",getVentasBrutas(), "tarifa de comision", getTarifaComision());
	}
}

/**************************************************************************
 * (C) Copyright 1992-2012 por Deitel & Associates, Inc. y * Pearson Education,
 * Inc. Todos los derechos reservados. * * RENUNCIA: Los autores y el editor de
 * este libro han realizado su mejor * esfuerzo para preparar este libro. Esto
 * incluye el desarrollo, la * investigaci�n y prueba de las teor�as y programas
 * para determinar su * efectividad. Los autores y el editor no hacen ninguna
 * garant�a de * ning�n tipo, expresa o impl�cita, en relaci�n con estos
 * programas o * con la documentaci�n contenida en estos libros. Los autores y
 * el * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de * estos
 * programas. *
 *************************************************************************/
