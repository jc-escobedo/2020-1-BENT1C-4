package unidad2.ejemplo7;
// Fig. 10.5: EmpleadoAsalariado.java
// La clase concreta EmpleadoAsalariado extiende a la clase abstracta Empleado.

public class EmpleadoAsalariado extends Empleado {
	private double salarioSemanal;
	// constructor de cuatro argumentos
	public EmpleadoAsalariado(String nombre, String apellido, String numeroSeguroSocial, double salario) {
		super(nombre, apellido, numeroSeguroSocial); // los pasa al constructor de Empleado
		setSalarioSemanal(salario); 				 // valida y almacena el salario
	}
	public void setSalarioSemanal(double salario) {
		if (salario >= 0.0)	salarioSemanal = salario;
		else		System.out.println("El salario semanal debe ser >= 0.0");
	}
	public double getSalarioSemanal() {
		return salarioSemanal;
	}
	// calcula los ingresos; sobrescribe el m�todo abstracto ingresos en Empleado
	@Override
	public double ingresos() {
		return getSalarioSemanal();
	}
	@Override
	public String toString() {
		return String.format("empleado asalariado: %s\n%s: $%,.2f", super.toString(), "salario semanal",getSalarioSemanal());
	}
}
/**************************************************************************
 * (C) Copyright 1992-2012 por Deitel & Associates, Inc. y * Pearson Education,
 * Inc. Todos los derechos reservados. * * RENUNCIA: Los autores y el editor de
 * este libro han realizado su mejor * esfuerzo para preparar este libro. Esto
 * incluye el desarrollo, la * investigaci�n y prueba de las teor�as y programas
 * para determinar su * efectividad. Los autores y el editor no hacen ninguna
 * garant�a de * ning�n tipo, expresa o impl�cita, en relaci�n con estos
 * programas o * con la documentaci�n contenida en estos libros. Los autores y
 * el * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de * estos
 * programas. *
 *************************************************************************/
