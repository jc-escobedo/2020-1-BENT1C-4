package unidad2.ejemplo7;
// Fig. 10.6: EmpleadoPorHoras.java
// La clase EmpleadoPorHoras extiende a Empleado.

public class EmpleadoPorHoras extends Empleado {
	private double sueldo; // sueldo por hora
	private double horas; // horas trabajadas por semana

	public EmpleadoPorHoras(String nombre, String apellido, String nss, double sueldoPorHoras, double horasTrabajadas) {
		super(nombre, apellido, nss);
		setSueldo(sueldoPorHoras); // valida y almacena el sueldo por horas
		setHoras(horasTrabajadas); // valida y almacena las horas trabajadas
	}
	public void setSueldo(double sueldoPorHoras) {
		if (sueldoPorHoras >= 0.0)
			sueldo = sueldoPorHoras;
		else
			System.out.println("El sueldo por horas debe ser >= 0.0");
	}
	public double getSueldo() {
		return sueldo;
	}
	public void setHoras(double horasTrabajadas) {
		if ((horasTrabajadas >= 0.0) && (horasTrabajadas <= 168.0))
			horas = horasTrabajadas;
		else
			System.out.println("Las horas trabajadas deben ser >= 0.0 y <= 168.0");
	}
	public double getHoras() {
		return horas;
	}
	// calcula los ingresos; sobrescribe el m�todo abstracto ingresos en Empleado
	@Override
	public double ingresos() {
		if (getHoras() <= 40) // no hay tiempo extra
			return getSueldo() * getHoras();
		else
			return 40 * getSueldo() + (getHoras() - 40) * getSueldo() * 1.5;
	}
	// devuelve representaci�n String de un objeto EmpleadoPorHoras
	@Override
	public String toString() {
		return String.format("empleado por horas: %s\n%s: $%,.2f; %s: %,.2f", super.toString(), "sueldo por hora",
				getSueldo(), "horas trabajadas", getHoras());
	}
}
/**************************************************************************
 * (C) Copyright 1992-2012 por Deitel & Associates, Inc. y * Pearson Education,
 * Inc. Todos los derechos reservados. * * RENUNCIA: Los autores y el editor de
 * este libro han realizado su mejor * esfuerzo para preparar este libro. Esto
 * incluye el desarrollo, la * investigaci�n y prueba de las teor�as y programas
 * para determinar su * efectividad. Los autores y el editor no hacen ninguna
 * garant�a de * ning�n tipo, expresa o impl�cita, en relaci�n con estos
 * programas o * con la documentaci�n contenida en estos libros. Los autores y
 * el * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de * estos
 * programas. *
 *************************************************************************/
