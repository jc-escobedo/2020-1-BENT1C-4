package unidad2.ejemplo1;
// Fig. 9.4: EmpleadoPorComision.java
// La clase EmpleadoPorComision representa a un empleado por comisi�n que recibe un porcentaje de las ventas brutas.
public class EmpleadoPorComision {
	private String primerNombre;
	private String apellidoPaterno;
	private String numeroSeguroSocial;
	private double ventasBrutas; 		// ventas semanales totales
	private double tarifaComision; 		// porcentaje de comisi�n

	// constructor con cinco argumentos
	public EmpleadoPorComision(String primerNombre, String apellidoPaterno, String numeroSeguroSocial, double ventasBrutas, double tarifaComision) {
		// la llamada impl�cita al constructor de Object ocurre aqu�
		this.primerNombre = primerNombre;
		this.apellidoPaterno = apellidoPaterno;
		this.numeroSeguroSocial = numeroSeguroSocial;
		setVentasBrutas(ventasBrutas); 		// valida y almacena las ventas brutas
		setTarifaComision(tarifaComision); 	// valida y almacena la tarifa de comisi�n
	}
	// establece el primer primerNombre
	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre; // deber�a validar
	}
	// devuelve el primer primerNombre
	public String getPrimerNombre() {
		return primerNombre;
	}
	// establece el apellido paterno
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno; // deber�a validar
	}
	// devuelve el apellido paterno
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	// establece el n�mero de seguro social
	public void setNumeroSeguroSocial(String numeroSeguroSocial) {
		this.numeroSeguroSocial = numeroSeguroSocial; // deber�a validar
	}
	// devuelve el n�mero de seguro social
	public String getNumeroSeguroSocial() {
		return numeroSeguroSocial;
	}
	// establece el monto de ventas brutas
	public void setVentasBrutas(double ventas) {
		if (ventas >= 0.0)
			ventasBrutas = ventas;
		else
			System.out.println("Las ventas brutas deben ser >= 0.0");
	}
	// devuelve el monto de ventas brutas
	public double getVentasBrutas() {
		return ventasBrutas;
	}
	// establece la tarifa de comisi�n
	public void setTarifaComision(double tarifa) {
		if (tarifa > 0.0 && tarifa < 1.0)
			tarifaComision = tarifa;
		else
			System.out.println("La tarifa de comisi�n debe ser > 0.0 y < 1.0");
	}
	// devuelve la tarifa de comisi�n
	public double getTarifaComision() {
		return tarifaComision;
	}
	// calcula los ingresos
	public double ingresos() {
		return tarifaComision * ventasBrutas;
	}
	// devuelve representaci�n String del objeto EmpleadoPorComision
	@Override // indica que este m�todo sobrescribe el m�todo de una superclase
	public String toString() {
		return String.format("%s: %s %s\n%s: %s\n%s: %.2f\n%s: %.2f", "empleado por comision", primerNombre,
				apellidoPaterno, "numero de seguro social", numeroSeguroSocial, "ventas brutas", ventasBrutas,
				"tarifa de comision", tarifaComision);
	}
}

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y * Pearson Education,
 * Inc. Todos los derechos reservados. * * RENUNCIA: Los autores y el editor de
 * este libro han realizado su mejor * esfuerzo para preparar este libro. Esto
 * incluye el desarrollo, la * investigaci�n y prueba de las teor�as y programas
 * para determinar su * efectividad. Los autores y el editor no hacen ninguna
 * garant�a de * ning�n tipo, expresa o impl�cita, en relaci�n con estos
 * programas o * con la documentaci�n contenida en estos libros. Los autores y
 * el * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de * estos
 * programas. *
 *************************************************************************/
