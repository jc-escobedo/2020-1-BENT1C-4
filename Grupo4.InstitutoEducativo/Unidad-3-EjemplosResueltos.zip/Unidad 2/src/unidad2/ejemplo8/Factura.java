package unidad2.ejemplo8;
// Fig. 10.12: Factura.java
// La clase Factura implementa a PorPagar.

public class Factura implements PorPagar {
	private String numeroPieza;
	private String descripcionPieza;
	private int cantidad;
	private double precioPorArticulo;

	// constructor con cuatro argumentos
	public Factura(String pieza, String descripcion, int cuenta, double precio) {
		numeroPieza = pieza;
		descripcionPieza = descripcion;
		setCantidad(cuenta); // valida y almacena la cantidad
		setPrecioPorArticulo(precio); // valida y almacena el precio por art�culo
	} 
	public void setNumeroPieza(String pieza) {
		numeroPieza = pieza; // deber�a validar
	}
	public String getNumeroPieza() {
		return numeroPieza;
	}	public void segtDescripcionPieza(String descripcion) {
		descripcionPieza = descripcion; // deber�a validar
	}
	public String getDescripcionPieza() {
		return descripcionPieza;
	}
	public void setCantidad(int cuenta) {
		if (cuenta >= 0)
			cantidad = cuenta;
		else
			System.out.println("Cantidad debe ser >= 0");
	}
	public int getCantidad() {
		return cantidad;
	}
	
	public void setPrecioPorArticulo(double precio) {
		if (precio >= 0.0)
			precioPorArticulo = precio;
		else
			System.out.println("El precio por articulo debe ser >= 0");
	}
	public double getPrecioPorArticulo() {
		return precioPorArticulo;
	}
	@Override
	public String toString() {
		return String.format("%s: \n%s: %s (%s) \n%s: %d \n%s: $%,.2f", "factura", "numero de pieza",
				getNumeroPieza(), getDescripcionPieza(), "cantidad", getCantidad(), "precio por articulo",
				getPrecioPorArticulo());
	}
	// m�todo requerido para realizar el contrato con la interfaz PorPagar
	@Override
	public double getMontoPago() {
		return getCantidad() * getPrecioPorArticulo(); // calcula el costo total
	}
}
/**************************************************************************
 * (C) Copyright 1992-2012 por Deitel & Associates, Inc. y * Pearson Education,
 * Inc. Todos los derechos reservados. * * RENUNCIA: Los autores y el editor de
 * este libro han realizado su mejor * esfuerzo para preparar este libro. Esto
 * incluye el desarrollo, la * investigaci�n y prueba de las teor�as y programas
 * para determinar su * efectividad. Los autores y el editor no hacen ninguna
 * garant�a de * ning�n tipo, expresa o impl�cita, en relaci�n con estos
 * programas o * con la documentaci�n contenida en estos libros. Los autores y
 * el * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de * estos
 * programas. *
 *************************************************************************/