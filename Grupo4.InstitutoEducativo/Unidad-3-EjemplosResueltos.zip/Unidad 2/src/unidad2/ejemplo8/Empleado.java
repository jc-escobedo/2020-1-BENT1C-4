package unidad2.ejemplo8;

// Fig. 10.13: Empleado.java
// La superclase abstracta Empleado que implementa Interfase  PorPagar.

public abstract class Empleado implements PorPagar {
	private String primerNombre;
	private String apellidoPaterno;
	private String numeroSeguroSocial;
	public Empleado(String primerNombre, String apellido, String numeroSeguroSocial) {
		this.primerNombre = primerNombre;
		apellidoPaterno = apellido;
		this.numeroSeguroSocial = numeroSeguroSocial;
	}
	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}
	public String getPrimerNombre() {
		return primerNombre;
	}
	public void setApellidoPaterno(String apellido) {
		apellidoPaterno = apellido;
	}
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	public void setNumeroSeguroSocial(String numeroSeguroSocial) {
		this.numeroSeguroSocial = numeroSeguroSocial;
	}
	public String getNumeroSeguroSocial() {
		return numeroSeguroSocial;
	} 
	@Override
	public String toString() {
		return String.format("%s %s\nnumero de seguro social: %s", primerNombre, apellidoPaterno,
				numeroSeguroSocial);
	} 
	// Nota: Aqu� no implementamos el m�todo obtenerMontoPago de PorPagar, as�
	// que esta clase debe declararse como abstract para evitar un error de compilaci�n.
	// al intentar crear un objeto Empleado
}
/**************************************************************************
 * (C) Copyright 1992-2012 por Deitel & Associates, Inc. y * Pearson Education,
 * Inc. Todos los derechos reservados. * * RENUNCIA: Los autores y el editor de
 * este libro han realizado su mejor * esfuerzo para preparar este libro. Esto
 * incluye el desarrollo, la * investigaci�n y prueba de las teor�as y programas
 * para determinar su * efectividad. Los autores y el editor no hacen ninguna
 * garant�a de * ning�n tipo, expresa o impl�cita, en relaci�n con estos
 * programas o * con la documentaci�n contenida en estos libros. Los autores y
 * el * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de * estos
 * programas. *
 *************************************************************************/